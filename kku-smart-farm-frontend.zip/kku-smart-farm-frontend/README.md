    1. Clone repo
    2. yarn install
    3. yarn start
