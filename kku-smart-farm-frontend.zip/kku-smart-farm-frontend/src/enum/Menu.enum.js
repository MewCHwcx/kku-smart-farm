export const Menu = {
  home: "home",
  relay: "relay",
  censor: "censor",
  wifi: "wifi",
};
